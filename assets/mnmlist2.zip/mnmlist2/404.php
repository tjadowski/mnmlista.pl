<?php get_header(); ?>

	<div id="content">
	
	<h2><a href="/"><?php bloginfo('name'); ?></a> : <b>not found</b></h2>
<br>
<br>
Our search is lonely,<br>
as futile as this lost page<br>
Let's <a href="<?php echo get_option('home'); ?>/">go home</a> instead.
	</div>

<?php get_footer(); ?>