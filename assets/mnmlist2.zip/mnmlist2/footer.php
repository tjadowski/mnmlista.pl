<div id="footer">

	<p>
		<small><a href="/about/">more</a> :: <a href="http://mnmlist.com/uncopyright/">uncopyright</a> :: <a href="/less/">less</a></small>
	</p>
</div>
</div>

<?php wp_footer(); ?>

</body>
</html>
