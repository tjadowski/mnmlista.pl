<div id="footer">

	<p>
		<small><a href="http://mnmlist.com/uncopyright/">uncopyrighted</a> | <a href="http://mnmlist.com/theme/">mnmlist theme</a> for <a href="http://wordpress.org">Wordpress</a></small>
	</p>
</div>
</div>

<?php wp_footer(); ?>
</body>
</html>
