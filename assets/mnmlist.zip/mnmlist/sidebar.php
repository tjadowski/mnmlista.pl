	<div id="sidebar">
				
		<ul>			
<li><a href="http://example.com/about/">about</a></li>
<li><a href="http://example.com/best-posts/">best posts</a></li>
<li><a href="http://example.com/links/">links</a></li>
<li><a href="http://feeds.feedburner.com/example">rss</a> | <a href="http://feedburner.google.com/fb/a/mailverify?uri=example&amp;loc=en_US">email</a></li>
		</ul>
	</div>

